
# This is Egony "fork" of Koenkk firmwares for Texas Instruments chips.
# https://github.com/Koenkk/Z-Stack-firmware/tree/master/coordinator/Z-Stack_3.x.0

# https://github.com/egony/cc2652p_E72-2G4M20S1E/tree/master/firmware/coordinator
# https://github.com/egony/cc2652p_cc1352p_RF-STAR/tree/main/firmware/coordinator
# https://github.com/egony/cc2652p7_RF-STAR/tree/main/firmware/coordinator 
# https://github.com/egony/cc2674p10_Ebyte/tree/main/firmware/coordinator

# Compiling the firmware

This guide describes how to compile both the router and coordinator firmware.

## Setup development environment

1. Download and install [SIMPLELINK-LOWPOWER-F2-SDK 8.32.00.07](https://www.ti.com/tool/download/SIMPLELINK-LOWPOWER-F2-SDK/8.32.00.07)
1. Download and install [Code Composer Studio 20.4.0](https://www.ti.com/tool/download/CCSTUDIO/20.4.0)

## Compiling

1. Create a folder called `workspace` in the folder where the SDK is installed. In the SDK installation folder you should see files like `Makefile` and `license_simplelink_cc13xx_cc26xx_sdk_8_32_00_07.txt`.
1. Start Code Composer Studio, it will ask you to select a workspace folder, select the `workspace` folder you created in the previous step.
1. Go to _File -> Import Projects -> Browse_ and select: `simplelink_cc13xx_cc26xx_sdk_8_32_00_07/examples/rtos`.
1. Select:
   - `znp_CC1352P_2_LAUNCHXL_tirtos7_ticlang`
   - `znp_LP_CC1352P7_4_tirtos7_ticlang`
   - `znp_LP_EM_CC2674P10_tirtos7_ticlang`
1. Press _Finish_.
1. In Code Composer Studio, expand the projects and for each open `znp.syscfg`, expand `Power Management` and change `Minimal Poll Period (ms)` to `1000`, change it back to `100` immediately and save the file.
1. Copy `*.patch` to the SDK installation folder, open a Git Bash in this folder and apply the patch using `git apply *.patch --ignore-space-change`.
1. Copy my files into folders.
1. Build the projects; click _Project_ -> _Build all_.
   - **Important:** by default the **launchpad** variant of the CC1352P2_CC2652P (= `CC1352P_2_LAUNCHXL_tirtos7_ticlang`) is build. To build the **other** variant change `#define LAUNCHPAD_CONFIG 1` to `#define LAUNCHPAD_CONFIG 0` in `preinclude.h`.
1. Once finished, the coordinator firmwares can be found under `znp_*_tirtos7_ticlang/default/znp_*_tirtos7_ticlang.hex`
   - `*_CC1352P_2_LAUNCHXL_tirtos7_ticlang.hex` -> CC1352P-2 and CC2652P based boards
   - `*_LP_CC1352P7_4_tirtos7_ticlang.hex` -> CC1352P7 based boards
   - `*_LP_EM_CC2674P10_tirtos7_ticlang.hex` -> CC2674P10 based boards
1. To package all the firmwares, execute `python3 package.py` in the SDK folder.
