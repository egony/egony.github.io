// Increase MAC buffers, multiplied default value by 10
#undef MAC_CFG_TX_DATA_MAX
#define MAC_CFG_TX_DATA_MAX 50
#undef MAC_CFG_TX_MAX
#define MAC_CFG_TX_MAX 80 
#undef MAC_CFG_RX_MAX
#define MAC_CFG_RX_MAX 50

// From https://www.ti.com/lit/an/swra650b/swra650b.pdf
#define LINK_DOWN_TRIGGER 12
#define NWK_ROUTE_AGE_LIMIT 5
#define DEF_NWK_RADIUS 15
#define DEFAULT_ROUTE_REQUEST_RADIUS 8
#define ZDNWKMGR_MIN_TRANSMISSIONS 0
#define ROUTE_DISCOVERY_TIME 13
#define MTO_RREQ_LIMIT_TIME 5000

// Increase NV pages to allow for bigger device tables
#ifdef EM_CC2674P10_LP
    #undef NVOCMP_NVPAGES
    #define NVOCMP_NVPAGES 10 // not matter - internally TI software can't work with big volumes, as I heard
#else
    #undef NVOCMP_NVPAGES
    #define NVOCMP_NVPAGES 3
#endif

// Determines the maximum number of “secure partners” that the network Trust Center (ZC) can support. 
// This value will be the upper limit of Zigbee 3.0 devices which are allowed in the network
#ifdef EM_CC2674P10_LP
// https://e2e.ti.com/support/wireless-connectivity/zigbee-thread-group/zigbee-and-thread/f/zigbee-thread-forum/1385908/lp-em-cc1354p10-zdsecmgr_tc_device_max-upper-limit
// https://e2e.ti.com/support/wireless-connectivity/zigbee-thread-group/zigbee-and-thread/f/zigbee-thread-forum/1323831/cc2674p10-zcd_nv_startup_option-appears-to-be-read-only-on-adapter-bootup
// https://dev.ti.com/tirex/content/simplelink_cc13xx_cc26xx_sdk_7_10_02_23/docs/zigbee/html/zigbee/flash_memory-cc13xx_cc26xx.html#modifying-non-volatile-memory-allocation
// !!! ATTENTION !!! If the coordinator doesn't start or starts but is very slow (it doesn't see some messages from the device) when pairing and working, you need to reduce the volume of what is written to the NVRAM !!!
    #define ZDSECMGR_TC_DEVICE_MAX 100 // 200 - no!
//    #define ZDSECMGR_TC_DEVICE_MAX 400 // !!! no no no !!! // default 40
#else
    #define ZDSECMGR_TC_DEVICE_MAX 200
#endif

// Increase the max number of boardcasts, the default broadcast delivery time is 3 seconds
// with the value below this will allow for 1 broadcast every 0.15 second
#define MAX_BCAST 30

//  Determines the maximum number of devices in the Neighbor Table.
#define MAX_NEIGHBOR_ENTRIES 50

// Number of devices in the standard Routing Table, which is used for AODV routing.
// Only stores information for 1-hop routes, so this table does not need to be as big as the Source Route table.
#define MAX_RTG_ENTRIES 150
#define ROUTE_EXPIRY_TIME 2

#ifdef IS_COORDINATOR
    #ifndef CC1352P_2
      // Firmware version, used in mt_version.c
    #define CODE_REVISION_NUMBER 20260101
    #endif

    // Required, otherwise firmware crashes after some uptime in some cases.
    #define NVOCMP_RECOVER_FROM_COMPACT_FAILURE

    // Required in order to use the extended MT API commands.
    #define FEATURE_NVEXID 1

    // Grants access to the security key data
    #define MT_SYS_KEY_MANAGEMENT 1

    // Increase by 1 to compensate for lag (default is 7)
    #define NWK_INDIRECT_MSG_TIMEOUT 8

    // Increase frame retries
    #define ZMAC_MAX_FRAME_RETRIES 7
    #define NWK_MAX_DATA_RETRIES 4

    // Disabling MULTICAST is required in order for proper group support.
    // If MULTICAST is not disabled, the group adress is not included in the APS header
    #define MULTICAST_ENABLED FALSE

    // Reduce the APS ack wait duration from 6000 ms to 1000 ms (value * 2 = value in ms).
    // This will make requests timeout quicker, in pratice the default timeout of 6000ms is too long.
    #define APSC_ACK_WAIT_DURATION_POLLED 500

    // Enable MTO routing
    // MTO Routing will be used in addition to the standard AODV routing to provide additional route discovery opportunities.
    // Especially useful for larger networks with multiple hops.
    #define CONCENTRATOR_ENABLE TRUE
    #define CONCENTRATOR_ROUTE_CACHE TRUE
    #define CONCENTRATOR_DISCOVERY_TIME 60
    #define MAX_RTG_SRC_ENTRIES 250
    #define SRC_RTG_EXPIRY_TIME 10

    // The number of simultaneous route discoveries in network
    #define MAX_RREQ_ENTRIES 40

    // Size of the conflicted address table
    #define CONFLICTED_ADDR_TABLE_SIZE 15

    // Number of devices which have associated directly through the coordinator
    // This does not determine the upper limit in the number of nodes in the network, 
    // just the upper limit for number of nodes directly connected to a certain routing node
    #ifdef EM_CC2674P10_LP
    // !!! ATTENTION !!! If the coordinator doesn't start or starts but is very slow (it doesn't see some messages from the device) when pairing and working, you need to reduce the volume of what is written to the NVRAM !!!
        #define NWK_MAX_DEVICE_LIST 50 // default 20
    #else
        #define NWK_MAX_DEVICE_LIST 75
    #endif
#endif

#ifdef IS_ROUTER
    #define ZCL_GENERIC_APP_SW_BUILD_ID { 8, '2','0','2','5','0','4','0','3' }
    #define ZCL_REPORT_DESTINATION_DEVICE
    #define BDB_REPORTING
    #define CUI_DISABLE
    #define NWK_MAX_DEVICE_LIST     50
    #define ZDO_API_ADVANCED
    #define ATTRID_BASIC_TRANSMIT_POWER 0x1337
#endif

// CC2652P7 (Ebyte) specific
#if defined(DeviceFamily_CC13X2X7)
    #define TXPOWER 20
    #define SET_CCFG_MODE_CONF_XOSC_CAP_MOD         0x1  // Don't apply cap-array delta (yes, 1 means disabled)
    //#define SET_CCFG_MODE_CONF_XOSC_CAPARRAY_DELTA  0xc1 // pointless because cap array disabled
    #define SET_CCFG_MODE_CONF_DCDC_ACTIVE          0x0  // Use the DC/DC during active mode because DCDC enabled in RF-Star and Ebyte modules  (yes, 0 means enabled)
    #define SET_CCFG_MODE_CONF_DCDC_RECHARGE        0x0  // Use the DC/DC during recharge in powerdown (yes, 0 means enabled)
    #define CCFG_FORCE_VDDR_HH                      0x1  // Force VDDR voltage to the factory HH setting (necessary for high PA)
#endif

// CC2674P10 (Ebyte) specific
#if defined(EM_CC2674P10_LP)
    #define TXPOWER 20
    #define SET_CCFG_MODE_CONF_XOSC_CAP_MOD         0x0  // Apply cap-array delta (yes, 0 means enabled)
    #define SET_CCFG_MODE_CONF_XOSC_CAPARRAY_DELTA  0xFA // !!! mandatory for Ebyte module !!!
    #define SET_CCFG_MODE_CONF_DCDC_ACTIVE          0x0  // Use the DC/DC during active mode because DCDC enabled in RF-Star and Ebyte modules  (yes, 0 means enabled)
    #define SET_CCFG_MODE_CONF_DCDC_RECHARGE        0x0  // Use the DC/DC during recharge in powerdown (yes, 0 means enabled)
    #define CCFG_FORCE_VDDR_HH                      0x1  // Force VDDR voltage to the factory HH setting (necessary for high PA)
#endif

// CC1352P2 specific
#if defined(CC1352P_2)
    #define TXPOWER 20
    #define SET_CCFG_MODE_CONF_DCDC_ACTIVE          0x0  // Use the DC/DC during active mode because DCDC enabled in RF-Star and Ebyte modules  (yes, 0 means enabled)
    #define SET_CCFG_MODE_CONF_DCDC_RECHARGE        0x0  // Use the DC/DC during recharge in powerdown (yes, 0 means enabled)
    #define CCFG_FORCE_VDDR_HH                      0x1  // Force VDDR voltage to the factory HH setting (necessary for high PA)
    // Different configs, set `LAUNCHPAD_CONFIG` to `0` for "other" firmware
    #define LAUNCHPAD_CONFIG 1
    #if LAUNCHPAD_CONFIG == 1
      #ifdef IS_COORDINATOR
        #define CODE_REVISION_NUMBER 20260102 // even number for Launchpad / RF-STAR
      #endif
        #define CONFIG_RF_24GHZ                         0x0000001c
        #define CONFIG_RF_HIGH_PA                       0x0000001d
        #define SET_CCFG_MODE_CONF_XOSC_CAP_MOD         0x1  // Don't apply cap-array delta (yes, 1 means disabled)
        #define SET_CCFG_MODE_CONF_XOSC_CAPARRAY_DELTA  0xc1 // pointless because cap array disabled
        #define CONFIG_GPIO_RLED                        6
        #define CONFIG_GPIO_GLED                        7
    #else
      #ifdef IS_COORDINATOR
        #define CODE_REVISION_NUMBER 20260105 // odd number for Other / E-byte E72
      #endif
        #define CONFIG_RF_24GHZ                         0x0000006
        #define CONFIG_RF_HIGH_PA                       0x0000005
        #define SET_CCFG_MODE_CONF_XOSC_CAP_MOD         0x0  // Apply cap-array delta (yes, 0 means enabled)
        #define SET_CCFG_MODE_CONF_XOSC_CAPARRAY_DELTA  0xFA // !!! mandatory for Ebyte module !!!
        #define CONFIG_GPIO_RLED                        7
        #define CONFIG_GPIO_GLED                        8
    #endif
#endif
